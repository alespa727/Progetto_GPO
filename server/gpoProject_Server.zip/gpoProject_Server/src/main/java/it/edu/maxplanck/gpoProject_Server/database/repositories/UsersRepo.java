package it.edu.maxplanck.gpoProject_Server.database.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import it.edu.maxplanck.gpoProject_Server.database.model.User;

/**
 * Interfaccia che rappresenta le query da fare nel database degli utenti
 */
@Repository
public interface UsersRepo extends JpaRepository<User, Integer> {
	
    boolean existsUserByUsername(String username);

    User findUserByUsername(String username);
}