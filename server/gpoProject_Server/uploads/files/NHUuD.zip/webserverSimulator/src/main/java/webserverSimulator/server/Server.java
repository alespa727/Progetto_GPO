package webserverSimulator.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	//definisco un attributo di tipo ServerSocket che servirà 
	//per gestire(ed eventualmente accettare) le richieste che arrivano dalla rete. 
	private ServerSocket sSocket;
	
	public Server(int porta) throws IOException {
		System.out.println("SERVER ATTIVO");
		//creo l'oggetto ServerSocket in ascolto sulla porta definita nella variabile "porta"
		sSocket = new ServerSocket(porta);
	}

	//Metodo invocato nel main per iniziare l'ascolto delle richieste nel socket configurato sopra
	public void startAccept() {
		GestioneConnessione gConnessione;
		Thread t;
		//creo l'oggetto, comune a tutti i Thread, che si occuperà della gestione delle richieste accettate.
		gConnessione = new GestioneConnessione();
		try {
			//questo while tiene attivo il server  fino a che non termino il programma da eclipse.
			while(true) {
				//sSocket.accept();  resta in ascolto(in attesa) di una richiesta di connessione al socket 
				//definito sopra (sSocket). 
				//Appena rileva una richiesta la accetta e restituisce il socket del Client.
				//Questo metodo è bloccante, ovvero l'esecuzione del codice si 
				//blocca alla riga qui sotto finché non riceve una richiesta di connessione.  
				Socket socketCli = sSocket.accept(); 
				System.out.println(socketCli); 
				
				//assegno il socket del client all'oggetto dichiarato sopra e condiviso dai Thread
				gConnessione.setSocket(socketCli);
				//Creo il Thread e lo avvio
				t = new Thread(gConnessione);
				t.start();
				//NB:in questo modo ogni richiesta verrà assegnata ad un nuovo Thread
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
