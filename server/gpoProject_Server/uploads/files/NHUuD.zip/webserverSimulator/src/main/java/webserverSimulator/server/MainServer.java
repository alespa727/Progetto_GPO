package webserverSimulator.server;

import java.io.IOException;

public class MainServer {

	public static void main(String[] args) {
		int porta=8081;
		Server server;
		try {
			server = new Server(porta);
			server.startAccept();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Errore creazione oggetto Server: "+e.getMessage());
		}
		
	}

}
