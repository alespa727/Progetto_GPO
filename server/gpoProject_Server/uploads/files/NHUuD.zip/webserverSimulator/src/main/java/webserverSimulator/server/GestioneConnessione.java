package webserverSimulator.server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class GestioneConnessione implements Runnable{
	//oggetto per gestire il socket Client
	private Socket socket;

	public GestioneConnessione() {
		
		this.socket = new Socket();
	}
	
	public GestioneConnessione(Socket socket) {
		this.socket = socket;
	}
	
	@Override
	public void run() {
		BufferedReader input;
		BufferedWriter output;
			
		try {
			
			//creo gli oggetti per poter leggere (input) e scrivere (output) nel socket
			input = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			output = new BufferedWriter(new OutputStreamWriter(this.socket.getOutputStream()));
			
			//"comunica" è un metodo creato ad hoc per gestire le logiche di comunicazione.
			//non è indispensabile ma aiuta a rendere il codice più leggibile
			comunica(input, output);
			
			//terminata la logica per l'elaborazione della richiesta chiudo input, output e il socket
			input.close();
			output.close();
			this.socket.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}

	private void comunica(BufferedReader input, BufferedWriter output) throws IOException {
		//nome del thread
		String tNome = "[" + Thread.currentThread().getName() + "] ";	
		String richiesta = "";
		String risposta = "";
		
		System.out.println(tNome + "-- inizio richiesta --");
		//readline legge una linea. 
		//Una linea viene considerata come una stringa che termina con uno dei caratteri speciali 
		//'\n' oppure '\r' o in combinazione in sequenza '\r\n' oppure raggiungendo la fine del file EOF 
		richiesta=input.readLine(); 
		System.out.println(tNome + richiesta);
		
		if(richiesta==null) {
			//se la richiesta è null vuol dire che il client ha chiuso la connessione improvvisamente
			return;
		}
		
		//la richiesta del Client è formattata nel seguente modo: GET /nomepagina.html HTTP/1.1
		//divido le singole componenti della  stringa di richiesta (separate da spazio) e le salvo in un array 
		String pagina[]= richiesta.split(" "); 
		System.out.println(tNome + pagina[1]);
		
		//mi salvo l'estensione del file richiesto. endsWith("word") ritorna true se la stringa 
		//termina con i caratteri passati come paramentro, false in caso contrario. 
		boolean isHtmlPage= pagina[1].endsWith(".html");
		
		//OPZIONALE per l'esercizio: leggo le righe restanti finché non ne trovo una vuota 
		while(!richiesta.equals("")) {
			//nel resto delle righe di richiesta ci sono informazioni riguardanti il Client
			//Es: User-Agent -> tipo di client utilizzato (firefox), sistema operativo ecc..
			richiesta=input.readLine();
			System.out.println(tNome + richiesta);
			
			if(richiesta==null) {
				return;
			}
			
		}
		
		System.out.println(tNome + "-- fine richiesta --");
		//preparo la risposta 
		if(!isHtmlPage) {
			//404
			risposta="HTTP/1.1 404 Not found\n";
			risposta+="\n";
		}else {
			//200
			risposta="HTTP/1.1 200 OK\n";
			risposta+="Content-Type: text/html\n";
			risposta+="\n";
			risposta+="<html><head><title>Titolo</title></head><body><p>Risposta! pagina richiesta "+pagina[1]+"</p></body></html>\n";
			risposta+="\n";
		}
		System.out.println(tNome + "-- inizio risposta --");
		System.out.println(tNome + risposta);
		System.out.println(tNome + "-- fine risposta --");
		//scrivo nel socket
		output.write(risposta);
		//invio lo stream di dati
		output.flush();
	}
	
	public void setSocket(Socket socket) {
		this.socket = socket;
	}

}
